"""This module provides generic functions for encoding and decoding protobufs
   to python dictionaries or JSON
"""
from .api import *
