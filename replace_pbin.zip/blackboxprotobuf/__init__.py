"""This module provides generic functions for encoding and decoding protobuf's
   to python dictionaries or JSON
"""
from blackboxprotobuf.lib.api import *
